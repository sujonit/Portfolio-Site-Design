
document.getElementById("contactForm").addEventListener("submit", function (e) {
  alert("Message sent! Thank you.");
});
