Personal Portfolio HTML Template

Thank you for downloading this template.

How to Use:
------------
1. Open index.html in any browser.
2. Edit index.html to change text, images, and links.
3. Contact form requires a live PHP server and reCAPTCHA keys.
4. Replace your@email.com in contact.php to receive messages.

License:
--------
All code is custom.
Images are placeholders. Replace before publishing.

Need Help?
----------
Email: tomal@malwareremoval.us
